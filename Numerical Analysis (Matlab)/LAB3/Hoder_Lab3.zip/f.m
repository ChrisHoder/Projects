function out = f(x),
    out = 10*x + exp(x)*cos(10*x);

end